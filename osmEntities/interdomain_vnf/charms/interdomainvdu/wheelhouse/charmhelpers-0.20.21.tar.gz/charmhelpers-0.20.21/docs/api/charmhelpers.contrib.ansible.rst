charmhelpers.contrib.ansible package
====================================

.. automodule:: charmhelpers.contrib.ansible
    :members:
    :undoc-members:
    :show-inheritance:
